Appointment Prep Card

Date: 2026-06-28
Summary: A one-page prep card for collecting questions, documents, and follow-up notes before an appointment.
Buyer: People who forget key questions or documents when appointments get stressful.

Included files: pack page, printable worksheet, checklist, cover SVG, manifest JSON, and seller-copy markdown.
This ZIP is generated for digital-product upload workflows. It contains no payment credentials or guaranteed-income claims.
See SUPPORT.txt for the voluntary support URL for this pack.