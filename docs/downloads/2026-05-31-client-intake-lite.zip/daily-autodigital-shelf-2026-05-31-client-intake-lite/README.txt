Client Intake Lite

Date: 2026-05-31
Summary: A small intake sheet for turning a vague request into scope, timeline, budget, and next action.
Buyer: Service providers who need a repeatable first-call intake without a heavy CRM.

Included files: pack page, printable worksheet, checklist, cover SVG, manifest JSON, and seller-copy markdown.
This ZIP is generated for digital-product upload workflows. It contains no payment credentials or guaranteed-income claims.