Store Import Prep Sheet

Date: 2026-05-14
Summary: A worksheet for gathering product title, description, price hint, tags, and delivery files before using a store platform.
Buyer: Digital sellers preparing listings for Payhip, Gumroad, Etsy-style shops, or similar platforms.

Included files: pack page, printable worksheet, checklist, cover SVG, manifest JSON, and seller-copy markdown.
This ZIP is generated for digital-product upload workflows. It contains no payment credentials or guaranteed-income claims.