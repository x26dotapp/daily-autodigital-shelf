Project Rescue Map

Date: 2026-05-10
Summary: A one-page map for rescuing a messy project by separating assets, blockers, risks, and next moves.
Buyer: Builders and operators who need to recover a project without starting over.

Included files: pack page, printable worksheet, checklist, cover SVG, manifest JSON, and seller-copy markdown.
This ZIP is generated for digital-product upload workflows. It contains no payment credentials or guaranteed-income claims.
See SUPPORT.txt for the voluntary support URL for this pack.