Two-Hour Workblock Planner

Date: 2026-05-13
Summary: A compact planning sheet for choosing one outcome, one timer, and one shutdown note.
Buyer: People who need a bounded work session that does not expand into the whole day.

Included files: pack page, printable worksheet, checklist, cover SVG, manifest JSON, and seller-copy markdown.
This ZIP is generated for digital-product upload workflows. It contains no payment credentials or guaranteed-income claims.
See SUPPORT.txt for the voluntary support URL for this pack.