Weekly Reset Board

Date: 2026-06-03
Summary: A printable reset board for tasks, bills, errands, and loose ends that need one weekly review.
Buyer: Busy households and solo workers who need one visible weekly reset page.

Included files: pack page, printable worksheet, checklist, cover SVG, manifest JSON, and seller-copy markdown.
This ZIP is generated for digital-product upload workflows. It contains no payment credentials or guaranteed-income claims.
See SUPPORT.txt for the voluntary support URL for this pack.