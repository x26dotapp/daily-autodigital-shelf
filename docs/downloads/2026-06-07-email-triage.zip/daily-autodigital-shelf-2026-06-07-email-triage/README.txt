Email Triage Sprint

Date: 2026-06-07
Summary: A 15-minute inbox worksheet for finding the few messages that actually need action.
Buyer: People who avoid inboxes because every message feels equally urgent.

Included files: pack page, printable worksheet, checklist, cover SVG, manifest JSON, and seller-copy markdown.
This ZIP is generated for digital-product upload workflows. It contains no payment credentials or guaranteed-income claims.
See SUPPORT.txt for the voluntary support URL for this pack.