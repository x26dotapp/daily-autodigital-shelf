Low-Energy Week Planner

Date: 2026-06-19
Summary: A gentle planning sheet for weeks where consistency matters more than intensity.
Buyer: Disabled and neurodivergent workers who need low-friction planning without motivational noise.

Included files: pack page, printable worksheet, checklist, cover SVG, manifest JSON, and seller-copy markdown.
This ZIP is generated for digital-product upload workflows. It contains no payment credentials or guaranteed-income claims.
See SUPPORT.txt for the voluntary support URL for this pack.