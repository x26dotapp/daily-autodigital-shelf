Subscription Audit Sheet

Date: 2026-06-24
Summary: A quick worksheet for finding recurring charges, renewal dates, and pause candidates.
Buyer: Households and freelancers who need a clearer view of subscriptions without a finance app.

Included files: pack page, printable worksheet, checklist, cover SVG, manifest JSON, and seller-copy markdown.
This ZIP is generated for digital-product upload workflows. It contains no payment credentials or guaranteed-income claims.
See SUPPORT.txt for the voluntary support URL for this pack.