Micro Budget Reset

Date: 2026-05-23
Summary: A one-page reset for seeing near-term bills, small leaks, and the next cash decision.
Buyer: Solo households and freelancers who need a short money picture without a complex finance app.

Included files: pack page, printable worksheet, checklist, cover SVG, manifest JSON, and seller-copy markdown.
This ZIP is generated for digital-product upload workflows. It contains no payment credentials or guaranteed-income claims.
See SUPPORT.txt for the voluntary support URL for this pack.