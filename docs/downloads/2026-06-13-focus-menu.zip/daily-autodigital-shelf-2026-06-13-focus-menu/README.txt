Focus Menu Builder

Date: 2026-06-13
Summary: A menu of low, medium, and high energy task options for days when planning from scratch is too expensive.
Buyer: People who need usable work choices that adapt to uneven energy.

Included files: pack page, printable worksheet, checklist, cover SVG, manifest JSON, and seller-copy markdown.
This ZIP is generated for digital-product upload workflows. It contains no payment credentials or guaranteed-income claims.
See SUPPORT.txt for the voluntary support URL for this pack.