Invoice Follow-Up Mini Kit

Date: 2026-05-28
Summary: A calm worksheet for tracking unpaid invoices and writing one clear follow-up.
Buyer: Freelancers and service providers who need a polite payment follow-up without pressure tricks.

Included files: pack page, printable worksheet, checklist, cover SVG, manifest JSON, and seller-copy markdown.
This ZIP is generated for digital-product upload workflows. It contains no payment credentials or guaranteed-income claims.