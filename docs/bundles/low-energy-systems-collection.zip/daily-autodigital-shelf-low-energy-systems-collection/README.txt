Low-Energy Systems Collection Bundle

Gentle planning packs for uneven energy, neurodivergent workflows, shutdown notes, and low-friction task choices.

Pack count: 14
Date range: 2026-05-13 to 2026-06-26
Offer page: https://x26dotapp.github.io/daily-autodigital-shelf/offers/low-energy-systems.html
Topic page: https://x26dotapp.github.io/daily-autodigital-shelf/topics/low-energy-systems.html

This bundle contains public generated worksheets, checklists, cover SVGs, manifests, seller-copy files, individual ZIPs, and download landing pages for one topic collection.
It is designed as a focused digital-download bundle that can be supported voluntarily while checkout is disconnected.

Guardrails: no guaranteed-income claims, no payment credentials, no medical/legal/investment advice, and no hidden live-fund behavior.